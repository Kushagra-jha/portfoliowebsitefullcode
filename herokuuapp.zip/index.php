
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-sclae=1">
        <title>Kushagra Jha | Web Designer</title>
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-mfizz/2.4.1/font-mfizz.min.css"
    integrity="sha256-KkbZmx6FZVSEtoV2osxWijO2la7keAhUtFPsV0IPkv8=" crossorigin="anonymous" />
  <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/emailjs-com@2.4.1/dist/email.min.js"></script>
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
	<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="css/util.css">
		<link rel="stylesheet" type="text/css" href="css/main.css">
	<!--===============================================================================================-->
        <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
        <link href="https://fonts.googleapis.com/css2?family=Galada&display=swap" rel="stylesheet">
        <link href="//db.onlinewebfonts.com/c/0923ee644c97a87d70269aa80a6f1e79?family=The+Historia+Demo" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link rel="stylesheet" href="main.css">        
    </head>
    <body> 
        
        
        <header id="home"> 
         <div class="menu-toggler">
         <div class="bar half start"></div>
         <div class="bar open"></div>
         <div class="bar half end"></div>
         </div>
         <nav class="top-nav">
             <ul class="nav-list">
                 <li><a href="#home" class="nav-link js-scroll-trigger">Home</a></li>
                 <li><a href="#about" class="nav-link">About Me</a></li>
                 <li><a href="#skills" class="nav-link">My Skills</a></li>
                 <li><a href="#experience" class="nav-link">My Experience</a></li>
                 <li><a href="#portfolio" class="nav-link">Portfolio</a></li>
                 <li><a href="#contact" class="nav-link">Contact Me</a></li> 
                                
                  </ul>            
         </nav>
         <div class="landing-text">
             <h1>
                 Kushagra Jha
             </h1>
             <h6>
                 Web Designer and Developer
             </h6>
         </div>
         </header>


          <section class="about" id="about">
              <div class="container">
                  <div class="profile-img">
                      <img src="images/profile.jpg" alt="profile">
                  </div>
                  <div class="about-details">
                      <div class="about-heading">
                          <h1>About</h1>
                          <h6>Myself</h6>
                      </div>
                      <p class="pabt">
                          Hello, I'm Kushagra Jha an open source front end Web Designer and Developer. I like to do UI/UX designing and I'm proficient in HTML5, CSS, JAVA SCRIPT, PHP and PYTHON. I also like to solve code and design problems using JAVASCRIPT. Thank u ❤  for reading
                         </p>
                         <div class="social-media">
                            <ul class="nav-list">
                                <li>
                                    <a href="error.html" class="icon-link" target="blank">
                                        <i class="fab fa-facebook-square"></i>
                                    </a>
                                </li>
                                <li>
                                  <a href="error.html" class="icon-link" target="blank">
                                      <i class="fab fa-twitter-square"></i>
                                  </a>
                              </li>
                              <li>
                                  <a href="https://github.com/Kushagra-jha" class="icon-link" target="blank"> 
                                      <i class="fab fa-github-square"></i>
                                  </a>
                              </li>
                            </ul>
                        </div>
                  </div> 
                  
              </div>
          </section>
          <section class="services" id="skills">
              <div class="container">
                  <div class="section-heading">
                      <h1>My skills</h1>
                      <h6>What can I do ?</h6>
                  </div><br><br>
                  <div class="w3-light-grey">
                    <div class="w3-container w3-green w3-center" style="width:95%">HTML5</div>
                                  </div><br>
                  
                  <div class="w3-light-grey">
                    <div class="w3-container w3-red w3-center" style="width:92%">CSS3</div>
                  </div><br>
                  
                  <div class="w3-light-grey">
                    <div class="w3-container w3-blue" style="width:75%"><center>PHP</center></div>
                  </div><br>
                  <div class="w3-light-grey">
                    <div class="w3-container w3-yellow w3-center" style="width:45%">JAVASCRIPT</div>
                  </div><br>
                  <div class="w3-light-grey">
                    <div class="w3-container w3-grey w3-center" style="width:20%">PYTHON</div>
                  </div><br>
                  <center>
                      <div class="skill-icons">
                                                  <i class="fab fa-html5" style="font-size:78px;color: rgb(0, 234, 255);padding-right: 30px;"></i>
                        <i class="fab fa-css3" style="font-size:78px;color: rgb(0, 234, 255);padding-right: 30px;"></i>
                        <i class="icon-javascript-alt js" style="font-size:88px;color: rgb(0, 234, 255); padding-right: 30px;"></i>
                      </div>           
                  </center>
              </div>
          </section>
          <section class="portfolio" id="thiswebsite">
            <div class="container">
                <div class="section-heading">
                    <h1>This Website</h1>
                    <h6>Tricks to make the website</h6>
                </div>
                <div class="portfolio-item" >
                    <div class="portfolio-img has-margin-right"><img src="https://www.websolutionsz.com/wp-content/uploads/2017/06/Portfolio-web-design.jpg">
                    </div>
                    <div class="portfolio-description">
                        <h6>Web Development</h6>
                        <h1>Portfolio Website</h1>
                        <p class="ppp">A portfolio website is the quickest and easiest way of showcasing your work as a designer.
                            </p>
                                                <a href="comingsoon.html" class="cta">View Details</a>

                    </div>
                </div>
                <div class="portfolio-item">
                    <div class="portfolio-description">
                        <h6>Web Layout</h6>
                        <h1>Website layout</h1>
                        <p class="ppp">A website is often divided into headers, menus, content and a footer.There are tons of different layout designs to choose from. However, the structure given. And in this website I have used this structuer only.



                        </p>
                    <a href="comingsoon.html" class="cta">View Details</a>
                    
                    </div>
                    <div class="portfolio-img has-margin-right"><img src="images/portitem2.jpeg" alt="">
                    </div>
                    
                </div>
                <div class="portfolio-item">
                    <div class="portfolio-img has-margin-right"><img src="images/portitem3.jpeg" alt="">
                    </div>
                    <div class="portfolio-description">
                        <h6>Design Sketch</h6>
                        <h1>Website Sketch</h1>
                        <p class="ppp">Since there are numerous benefits of a pre-planned website. My this website was also Pre-planned. It took me three Days to make this fully responsive but simple website. Thankyou For reading</p>
                    <a href="comingsoon.html" class="cta">View Details</a>
                    
                    </div>
                </div>
                </div>
          </section>
         

          <section class="experience" id="experience">
            <div class="container">
                <div class="section-heading">
                    <h1>Coding Experience</h1>
                    <h6>My life with Coding</h6>
                </div>
                    <center>    <div class="timeline">
                            <ul>
                                <li class="date" data-date="2020-present"></li>
                                <h1>PHP and JAVASCRIPT</h1>
                                <p> Eventually till Today's Date I have learned HTML, CSS, PYTHON, JAVASCRPIPT, PHP.</p>
                            </ul>
                        </div>

                        <div class="timeline">
                            <ul>
                                <li class="date" data-date="2018-2019"></li>
                                <h1>PYTHON</h1>
                                <p>Since I had learned HTML and CSS completely in one year only I did all the basic and advance course of PYTHON.</p>
                            </ul>
                        </div>

                        <div class="timeline">
                            <ul>
                                <li class="date" data-date="2017-2018"></li>
                                <h1>HTMl , CSS</h1>
                                <p>I spent two years in Learning HTML and CSS compltely. As I was new to coding at that time it took ample of time to learn the new language #HTML. </p>
                            </ul>
                        </div>
</center>

               </div>
          </section>
          
          <!-- portfolio -->
          
          <section class="portfolio" id="portfolio">
            <div class="container">
                <div class="section-heading">
                    <h1>Portfolio</h1>
                    <h6>View some of my Works</h6>
                </div>
                <img src="images/CHILLEIMG2.png" alt="fff" width="100px"><br><center><a class="button" href="chille/chille.html">VIEW</a></center><br><br><br><br>
                <img src="images/LEICAM62.png" alt="fff" width="100px"><br><center><a class="button" href="camera/camera.html">VIEW</a></center><br><br>
                <img src="images/osms.png" alt="fff" width="100px"><br><center><a class="button" href="OSMS_PHP/blablabla.php">VIEW</a></center><br><br>
                <img src="images/car.png" alt="car"><br><center><a class="button" href="amaz.html">VIEW</a></center>
</div>
          </section>


          <section class="contact" id="contact">
            <div class="container">
                <div class="section-heading">
                    <h1>Contact Me</h1>
                    <h6>Let's Work Together</h6>
                </div>
				<div class="contact1">
					<div class="container-contact1">
						<div class="contact1-pic js-tilt" data-tilt>
							<img src="images/img-01.png" alt="IMG">
						</div>
			
						<form class="contact1-form validate-form">
							<span class="contact1-form-title">
								Get in touch
							</span>
			
							<div class="wrap-input1 validate-input" data-validate = "Name is required">
								<input class="input1" type="text" name="name" placeholder="Name">
								<span class="shadow-input1"></span>
							</div>
			
							<div class="wrap-input1 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
								<input class="input1" type="text" name="email" placeholder="Email">
								<span class="shadow-input1"></span>
							</div>
			
							<div class="wrap-input1 validate-input" data-validate = "Subject is required">
								<input class="input1" type="text" name="subject" placeholder="Subject">
								<span class="shadow-input1"></span>
							</div>
			
							<div class="wrap-input1 validate-input" data-validate = "Message is required">
								<textarea class="input1" name="message" placeholder="Message"></textarea>
								<span class="shadow-input1"></span>
							</div>
			
							<div class="container-contact1-form-btn">
								<button class="contact1-form-btn">
									<span>
										Send Email
										
									</span>
								</button>
							</div>
						</form>
					</div>
				</div>
			
<br><br>
<center>
               <div>
                  
                      <h3> Made with ❤  by Kushagra Jha.</h3> <h3>You can find the source code <a href="https://github.com/Kushagra-jha/profilewebd" class="here" target="blank">Here</a></h3>
                   
               </div>
               </center>
</div>
</section>





                <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
                <script src="main.js"></script>
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  // Add smooth scrolling to all links
  $("a").on('click', function(event) {

    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){

        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
});
</script>

<!--===============================================================================================-->
<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>

<!--===============================================================================================-->
	<script src="js/main.js"></script>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
  AOS.init();
</script>

	<script>
        $(document).ready(function(){
            $('.carousel').carousel();
    
    
        // function for next slide
            $('.next').click(function(){
                $('.carousel').carousel('next');
            });
        
        // function for prev slide
            $('.prev').click(function(){
                $('.carousel').carousel('prev');
            });
        });
    </script>     
    </body>
<style>
   .here{
       color: indianred;
       
   }
  .sub{
      color: rgb(87, 52, 243);
  }
  #name{
      color: rgb(87, 52, 243);
  }
    .chilleimg{
        height: 45vh;
        width: 75vh;
    }
    .chill{
        padding-left: 65vh;
        font-size: 20px;
        line-height: 0;
        
    }

    .button {
  background-image: linear-gradient(to left, rgb(8, 246, 246), rgb(0, 110, 255), rgb(77, 41, 241));
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
    .button:hover{
        background-image: linear-gradient(to right, rgb(8, 246, 246), rgb(0, 110, 255), rgb(77, 41, 241)) ;
    }
    .leca{
        background-color: #221e3f;
    }
    .w3-blue:hover{
        background-color: indigo;
        color: ivory;
    }
    .contain2{
        justify-content: right;
        align-items: right;
        text-align: center;
        padding-left: 100vh;

    }
    .contain1{
        justify-content: left;
            align-items: left;
            padding-right: 100vh;
}
.button1{
         width: 1000px;
         height: 200px;
    
     }
</style>


</html>


